September 11, 2011

This package contains the DOS command line enhancement program doskey.com.
This is a 16-bit terminate-and-stay-resident (TSR) program.
See  http://paulhoule.com/doskey  for documentation and downloads.

Full source code is included in the src\ folder.

Two 32-bit Windows batch files are provided to build the doskey.com image.
One uses Microsoft tools (msbuild.bat), the other Japheth (jwbuild.bat).
The .bat files create byte-for-byte identical doskey.com images.

This program is distributed under the GPL 2.0 license (src\gpl-2.0.txt).
