@echo off
rem This is a Windows XP .bat file to compile doskey.com.
rem It assumes the required tools (JWasm.exe, JWlink.exe) are in the path.

rem Versions of Japheth tools used (http://japheth.de):
rem   JWasm  version 2.06e  (7/22/2011)
rem   JWlink version 1.9    (7/18/2011)

setlocal
rem order of source file list is crucial
set sf=dkres. dkint. dkdisp. dktab. dkstring. dkgotsr. dkexec.

jwasm /nologo /Zg /Cp %sf:.=.asm%
jwlink OPT q NAME doskey FORMAT dos com F {%sf:.=.obj%}
