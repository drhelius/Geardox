@echo off
rem This is a Windows XP .bat file to compile doskey.com.
rem It assumes the required tools (ml.exe, link.exe) are in the path.

rem Versions of Microsoft tools used were from MSVC 1.52:
rem   Microsoft (R) Macro Assembler Version 6.15.8803  (3/16/2000)
rem   Microsoft (R) Segmented Executable Linker  Version 5.60.339 Dec  5 1994

setlocal
rem order of source file list is crucial
set sf=dkres. dkint. dkdisp. dktab. dkstring. dkgotsr. dkexec.

ml /nologo /Cp /c %sf:.=.asm%
link /nologo /t %sf:.=.obj%,doskey.com;
