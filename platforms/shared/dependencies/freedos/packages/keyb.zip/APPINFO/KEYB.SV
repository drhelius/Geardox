Begin3
Language:    SV, 850, Swedish
Description: Tangentbordsdrivrutin (BIOS-niv�) f�r internationellt st�d
Keywords:    keyb, tangentbord, drivrutin
End
