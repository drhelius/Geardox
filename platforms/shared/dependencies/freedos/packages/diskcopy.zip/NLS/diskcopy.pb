# Language: brazilian
# File ending: pb
# Codepage: 858
# This translation was made by Google AI, please help
# the FreeDOS group to improve it.

0.0:S
0.1:N
#### Espa�o reservado para o arquivo diskcopy.c ####
1.0:Especifica��o de unidade inv�lida ou m�dia n�o remov�vel.
1.1:Erro ao ler o arquivo de configura��o.
1.2:Op��o inv�lida:
1.3:Muitos par�metros:
1.4:O arquivo est� protegido contra grava��o!
1.5:copiado para
1.6:Arquivo n�o encontrado:
1.7:O arquivo j� existe!
1.8:Insira o disquete de ORIGEM na unidade
1.9:Pressione qualquer tecla para continuar . . .
1.10:O disco n�o est� pronto!
1.11:N�o foi poss�vel abrir o arquivo de imagem.
1.12:Espa�o insuficiente no disco de destino!
1.13:Erro ao acessar o arquivo de imagem:
1.14:Mem�ria insuficiente para c�pia de disco.
1.15:Usando
1.16:arquivo tempor�rio.
1.17:Lendo o disquete de ORIGEM . . .
1.18:Erro de m�dia ao ler do setor
1.19:Gravando no arquivo de imagem.
1.20:Erro de mem�ria inesperado.
1.21:Insira o disquete de DESTINO na unidade
1.22:O disquete n�o tem a mesma capacidade que o original.
1.23:Coloque um disquete com a capacidade correta na unidade
1.24:ou pressione CTRL-C para cancelar.
1.25:Gravando no disquete de DESTINO na unidade . . .
1.26:Lendo do arquivo de imagem.
1.27:Erro de m�dia ao gravar no setor
1.28:Deseja outra c�pia deste
1.29:arquivo de imagem (S/N)?
1.30:disco (S/N)?
1.31:Copiar outro disco (S/N)?
1.32:N�o � poss�vel copiar o arquivo de imagem.
1.33:Problema ao ler o arquivo de imagem.
1.34:Criando arquivo de imagem . . .
1.35:Gravando arquivo de imagem . . .
1.36:Problema ao gravar arquivo de imagem.
1.37:Erro de compara��o no setor
1.38:Verificando . . .
1.39:Usando verifica��o
1.40:O n�mero de s�rie do volume �
1.41:Setor 0 n�o grav�vel! Protegido contra grava��o?
#### texto � "Warning: options % doesn't do anything!" ####
2.0:Aviso: a op��o
2.1:n�o faz nada!
#### texto � "Problem copying % to %" ####
3.0:Problema ao copiar
3.1:para
#### texto � "Copying % clusters, % sectors per cluster, ####
#### % bytes per sector.\n Drive size is % bytes" ####
4.0:Copiando
4.1:clusters
4.2:setores por cluster
4.3:bytes por setor.
4.4:O tamanho relevante da unidade �
4.5:bytes.
5.0:buffer de
5.1:bytes.
#### Espa�o reservado para o arquivo parser.c ####
6.0:Erro de sintaxe na linha
6.1:no arquivo de configura��o
6.2:Erro sem�ntico no arquivo de configura��o
6.3:n�o insira mais de um '='
6.4:Por favor, insira YES ou NO
6.5:Por favor, insira NEVER ou ALWAYS
6.6:por favor, insira RECOVERY ou NORMAL
6.7:por favor, insira FAST ou FULL
6.8:por favor, insira UPDATE ou LEAVE
#### Espa�o reservado para o arquivo recovery.c ####
6.10:Erro de m�dia ao ler, re-escaneando...
6.11:Setor ileg�vel na posi��o
#### Espa�o reservado para o arquivo tdrvcpy.c ####
7.0:Coloque o disquete de origem na unidade
7.1:Coloque o disquete de destino na unidade
7.2:Pressione qualquer tecla para continuar...
7.3:Unidade de origem inv�lida ou m�dia n�o remov�vel.
7.4:Unidade de destino inv�lida ou m�dia n�o remov�vel.
7.5:O disquete n�o tem a mesma capacidade que o original.
7.6:Erro de mem�ria insuficiente.
7.7:Erro de m�dia ao ler do setor
7.8:Erro de m�dia ao gravar no setor
7.9:Deseja copiar dois outros disquetes (s/n)?
8.0:Coloque um disquete com a capacidade correta na unidade
8.1:ou
8.2:ou pressione CTRL-C para cancelar.
9.0:Copiando
9.1:clusters
9.2:setores por cluster
9.3:bytes por setor.
9.4:O tamanho relevante da unidade �
9.5:bytes.
9.6:Copiando . . .
9.7:Verificando . . .
#### Espa�o reservado para a tela de ajuda ####
9.50:Copia um disquete ou arquivo de imagem para outro.
9.51:por
9.52:origem
9.53:destino
9.54:origem: unidade ou arquivo de imagem para copiar.
9.55:destino: unidade ou arquivo de imagem para gravar.
9.56:aviso sonoro para a��o do usu�rio.
9.57:verificar leituras e grava��es.
9.58:usar apenas mem�ria para c�pia.
9.59:mostrar uso de mem�ria (informativo).
9.60:sobrescrever destino, se existir (para imagens).
9.61:sempre sair automaticamente.
9.62:assumir que o disco j� est� na unidade.
9.63:entrar no modo de recupera��o de erro de disco.
9.64:c�pia r�pida (apenas setores preenchidos).
9.65:Notas: um sinal de menos ap�s uma op��o a desativa.
9.66: Pode especificar a mesma unidade para origem e destino.
9.67:no-op inclu�do para compatibilidade com MS-DOS.
9.40:n�o pedir disco se copiar imagem para o mesmo disco.
