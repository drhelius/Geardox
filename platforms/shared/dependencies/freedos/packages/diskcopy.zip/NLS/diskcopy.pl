# Language: polish
# File ending: pl
# Codepage: 852
# This translation was made by Google AI, please help
# the FreeDOS group to improve it.

0.0:T
0.1:N
#### Miejsce zarezerwowane dla pliku diskcopy.c ####
1.0:Nieprawid�owa specyfikacja nap�du lub no�nik niewymienny.
1.1:B��d odczytu pliku konfiguracyjnego.
1.2:Nieprawid�owy prze��cznik:
1.3:Zbyt wiele parametr�w:
1.4:Plik jest chroniony przed zapisem!
1.5:skopiowano do
1.6:Nie znaleziono pliku:
1.7:Plik ju� istnieje!
1.8:W��� dyskietk� �R�D�OW� do nap�du
1.9:Naci�nij dowolny klawisz, aby kontynuowa� . . .
1.10:Dysk nie jest gotowy!
1.11:Nie mo�na otworzy� pliku obrazu.
1.12:Brak miejsca na dysku docelowym!
1.13:B��d dost�pu do pliku obrazu:
1.14:Brak pami�ci do kopiowania dysku.
1.15:U�ycie
1.16:pliku tymczasowego.
1.17:Odczyt dyskietki �R�D�OWEJ . . .
1.18:B��d no�nika podczas odczytu sektora
1.19:Zapisywanie do pliku obrazu.
1.20:Nieoczekiwany b��d pami�ci.
1.21:W��� dyskietk� DOCELOW� do nap�du
1.22:Dyskietka nie ma tej samej pojemno�ci co orygina�.
1.23:W��� dyskietk� o w�a�ciwej pojemno�ci do nap�du
1.24:lub naci�nij CTRL-C, aby anulowa�.
1.25:Zapisywanie na dyskietk� DOCELOW� w nap�dzie . . .
1.26:Odczyt z pliku obrazu.
1.27:B��d no�nika podczas zapisu do sektora
1.28:Czy chcesz kolejn� kopi� tego
1.29:pliku obrazu (T/N)?
1.30:dysku (T/N)?
1.31:Skopiowa� inn� dyskietk� (T/N)?
1.32:Nie mo�na skopiowa� pliku obrazu.
1.33:Problem z odczytem pliku obrazu.
1.34:Tworzenie pliku obrazu . . .
1.35:Zapisywanie pliku obrazu . . .
1.36:Problem z zapisem pliku obrazu.
1.37:B��d por�wnania w sektorze
1.38:Weryfikacja . . .
1.39:U�ycie weryfikacji
1.40:Numer seryjny woluminu to
1.41:Sektor 0 niezapisywalny! Chroniony przed zapisem?
#### tekst to "Warning: options % doesn't do anything!" ####
2.0:Ostrze�enie: opcja
2.1:nic nie robi!
#### tekst to "Problem copying % to %" ####
3.0:Problem z kopiowaniem
3.1:do
#### tekst to "Copying % clusters, % sectors per cluster, ####
#### % bytes per sector.\n Drive size is % bytes" ####
4.0:Kopiowanie
4.1:klastr�w
4.2:sektor�w na klaster
4.3:bajt�w na sektor.
4.4:Rozmiar nap�du to
4.5:bajt�w.
5.0:bufor o rozmiarze
5.1:bajt�w.
#### Miejsce zarezerwowane dla pliku parser.c ####
6.0:B��d sk�adni w linii
6.1:w pliku konfiguracyjnym
6.2:B��d semantyczny w pliku konfiguracyjnym
6.3:nie wpisuj wi�cej ni� jeden '='
6.4:Prosz� wpisa� YES lub NO
6.5:Prosz� wpisa� NEVER lub ALWAYS
6.6:prosz� wpisa� RECOVERY lub NORMAL
6.7:prosz� wpisa� FAST lub FULL
6.8:prosz� wpisa� UPDATE lub LEAVE
#### Miejsce zarezerwowane dla pliku recovery.c ####
6.10:B��d no�nika podczas odczytu, ponowne skanowanie...
6.11:Nieczytelny sektor w pozycji
#### Miejsce zarezerwowane dla pliku tdrvcpy.c ####
7.0:W��� dyskietk� �r�d�ow� do nap�du
7.1:W��� dyskietk� docelow� do nap�du
7.2:Naci�nij dowolny klawisz, aby kontynuowa�...
7.3:Nieprawid�owy nap�d �r�d�owy lub no�nik niewymienny.
7.4:Nieprawid�owy nap�d docelowy lub no�nik niewymienny.
7.5:Dyskietka nie ma tej samej pojemno�ci co orygina�.
7.6:B��d: brak pami�ci.
7.7:B��d no�nika podczas odczytu sektora
7.8:B��d no�nika podczas zapisu do sektora
7.9:Czy chcesz skopiowa� dwie inne dyskietki (t/n)?
8.0:W��� dyskietk� o w�a�ciwej pojemno�ci do nap�du
8.1:lub
8.2:lub naci�nij CTRL-C, aby anulowa�.
9.0:Kopiowanie
9.1:klastr�w
9.2:sektor�w na klaster
9.3:bajt�w na sektor.
9.4:Rozmiar nap�du to
9.5:bajt�w.
9.6:Kopiowanie . . .
9.7:Weryfikacja . . .
#### Miejsce zarezerwowane dla ekranu pomocy ####
9.50:Kopiuje dyskietk� lub obraz na inn� dyskietk� lub obraz.
9.51:przez
9.52:�r�d�o
9.53:miejsce docelowe
9.54:�r�d�o: nap�d lub obraz, z kt�rego kopiowa�.
9.55:docelowy: nap�d lub obraz, na kt�ry kopiowa�.
9.56:ostrze�enie d�wi�kowe dla akcji u�ytkownika.
9.57:weryfikuj odczyty i zapisy.
9.58:u�ywaj tylko pami�ci RAM do kopiowania.
9.59:poka� zu�ycie pami�ci (informacyjne).
9.60:nadpisz cel, je�li ju� istnieje (dla obraz�w).
9.61:zawsze ko�cz automatycznie.
9.62:za�o�, �e dysk jest ju� w nap�dzie.
9.63:wejd� w tryb odzyskiwania b��d�w dysku.
9.64:szybkie kopiowanie (tylko zaj�te sektory).
9.65:Uwagi: znak minus po opcji j� wy��cza.
9.66: Mo�esz u�y� tego samego nap�du jako �r�d�a i celu.
9.67:no-op dla kompatybilno�ci z MS-DOS.
9.40:nie pytaj o dysk, je�li kopiujesz obraz na ten sam dysk.
